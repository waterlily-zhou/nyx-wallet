import { createWallet } from '@/lib/wallet';
import { cookies } from 'next/headers';
import { NextRequest, NextResponse } from 'next/server';
import { Hex } from 'viem';

export async function POST(req: NextRequest) {
  try {
    const { userId, deviceKey }: { userId: string; deviceKey: Hex } = await req.json();

    const { address } = await createWallet({
      method: 'biometric',
      userId,
      deviceKey,
    });

    const cookieStore = cookies();
    const isProd = process.env.NODE_ENV === 'production';

    cookieStore.set('walletAddress', address, {
      httpOnly: true,
      secure: isProd,
      sameSite: 'strict',
      path: '/',
    });

    cookieStore.set('session', 'authenticated', {
      httpOnly: true,
      secure: isProd,
      sameSite: 'strict',
      path: '/',
      maxAge: 24 * 60 * 60, // 24 hours
    });

    return NextResponse.json({ address });
  } catch (error) {
    console.error('Error creating wallet:', error);
    return NextResponse.json({ error: 'Failed to create wallet' }, { status: 500 });
  }
}
