'use client';

import { useState } from 'react';
import { useBiometricAuth } from '@/lib/hooks/useBiometricAuth';

export default function LoginPage() {
  const { isBiometricsAvailable, authenticateWithBiometrics } = useBiometricAuth();
  const [userId, setUserId] = useState('');
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleCreateWallet = async () => {
    setLoading(true);

    try {
      // 1. Authenticate with biometrics and get device key from /api/auth/verify
      const verifyRes = await fetch('/api/auth/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
      const { success, deviceKey } = await verifyRes.json();

      if (!success || !deviceKey) {
        throw new Error('Biometric verification failed');
      }

      // 2. Send userId + deviceKey to create wallet
      const res = await fetch('/api/wallet/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, deviceKey }),
      });

      const data = await res.json();
      if (data.address) setWalletAddress(data.address);
    } catch (error) {
      console.error('Error creating wallet:', error);
      alert('Failed to create wallet. Check console for details.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="p-4">
      <h1 className="text-xl font-bold mb-4">Biometric Wallet Login</h1>

      <input
        type="text"
        placeholder="Enter user ID"
        value={userId}
        onChange={(e) => setUserId(e.target.value)}
        className="border p-2 mb-4 w-full"
      />

      <button
        disabled={!isBiometricsAvailable || loading || !userId}
        onClick={handleCreateWallet}
        className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
      >
        {loading ? 'Creating...' : 'Create Wallet with Biometrics'}
      </button>

      {walletAddress && (
        <p className="mt-4">Wallet created: <code>{walletAddress}</code></p>
      )}
    </main>
  );
}