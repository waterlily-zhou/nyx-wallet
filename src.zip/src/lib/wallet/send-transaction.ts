import { type Address, parseEther } from 'viem';

export async function sendTransaction(
  from: Address,
  to: Address,
  value: bigint,
  data: string = '0x'
) {
  try {
    const nonce = await bundlerClient.getUserOperationCount({
      entryPoint: process.env.ENTRYPOINT_ADDRESS!,
      sender: from,
    });

    const userOperation = {
      sender: from,
      nonce,
      initCode: '0x',
      callData: data,
      callGasLimit: BigInt(100000),
      verificationGasLimit: BigInt(100000),
      preVerificationGas: BigInt(100000),
      maxFeePerGas: parseEther('0.000000001'),
      maxPriorityFeePerGas: parseEther('0.000000001'),
      paymasterAndData: '0x',
      signature: '0x',
    };

    // Get paymaster data
    const paymasterAndData = await paymasterClient.sponsorUserOperation({
      userOperation,
      entryPoint: process.env.ENTRYPOINT_ADDRESS!,
    });

    userOperation.paymasterAndData = paymasterAndData;

    // Sign the user operation
    // TODO: Implement signing logic

    // Send the user operation
    const userOpHash = await bundlerClient.sendUserOperation({
      userOperation,
      entryPoint: process.env.ENTRYPOINT_ADDRESS!,
    });

    return userOpHash;
  } catch (error) {
    console.error('Error sending transaction:', error);
    throw error;
  }
} 