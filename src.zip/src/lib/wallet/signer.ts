import { createHash, randomBytes } from 'crypto';
import { privateKeyToAccount } from 'viem/accounts';
import { Hex } from 'viem';
import { findUserById, decryptServerKey } from '@/lib/utils/user-store';

export function generateCombinedKey(deviceKey: Hex, serverKey: Hex): Hex {
  return `0x${createHash('sha256').update(deviceKey + serverKey).digest('hex')}` as Hex;
}

export async function createBiometricSigner(userId: string, deviceKey: Hex) {
  const user = findUserById(userId);
  if (!user || !user.serverKey) {
    throw new Error('User or server key not found');
  }

  const serverKey = decryptServerKey(user.serverKey, process.env.KEY_ENCRYPTION_KEY || '');
  const combinedKey = generateCombinedKey(deviceKey, serverKey);

  return privateKeyToAccount(combinedKey);
}

export function generateRandomPrivateKey(): Hex {
  return `0x${randomBytes(32).toString('hex')}` as Hex;
}

export function generateDistributedKeys(): {
  deviceKey: Hex;
  serverKey: Hex;
  recoveryKey: Hex;
} {
  const deviceKey = generateRandomPrivateKey();
  const serverKey = generateRandomPrivateKey();
  const recoveryKey = generateRandomPrivateKey();
  return { deviceKey, serverKey, recoveryKey };
}

export async function getCombinedKeys(userId: string): Promise<{
  deviceKey: Hex;
  serverKey: Hex;
  combinedKey: Hex;
}> {
  const user = findUserById(userId);
  if (!user || !user.serverKey) throw new Error('Missing keys');
  const serverKey = decryptServerKey(user.serverKey, process.env.KEY_ENCRYPTION_KEY || '');
  const deviceKey = '0x0000000000000000000000000000000000000000000000000000000000000000';
  const combinedKey = generateCombinedKey(deviceKey, serverKey);
  return { deviceKey, serverKey, combinedKey };
}
