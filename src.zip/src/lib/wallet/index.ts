import { Hex } from 'viem';
import { createSafeAccountFromBiometric } from './safe-account';
import { createSafeAccountClient } from './safe-account';
import { ClientSetup } from '../client-setup';

export type WalletCreationParams = {
  method: 'biometric';
  userId: string;
  deviceKey: Hex;
};

export async function createWallet(params: WalletCreationParams): Promise<{
  address: string;
  clientSetup: ClientSetup;
}> {
  const { method, userId, deviceKey } = params;

  if (method === 'biometric') {
    const signer = await createSafeAccountFromBiometric(userId, deviceKey);
    const { smartAccount, smartAccountClient, publicClient, pimlicoClient } = await createSafeAccountClient(signer);

    return {
      address: smartAccount.address,
      clientSetup: {
        owner: signer,
        smartAccount,
        smartAccountClient,
        publicClient,
        pimlicoClient,
      }
    };
  }

  throw new Error(`Unsupported wallet creation method: ${method}`);
}