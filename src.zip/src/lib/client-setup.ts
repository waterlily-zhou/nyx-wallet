import { createPublicClient, http, type Account, type PublicClient } from 'viem';
import { baseSepolia } from 'viem/chains';
import { createPimlicoClient } from 'permissionless/clients/pimlico';
import { createSmartAccountClient } from 'permissionless';
import { privateKeyToAccount } from 'viem/accounts';

// Constants
export const ENTRY_POINT_ADDRESS = '0x5FF137D4b0FDCD49DcA30c7CF57E578a026d2789' as const;

// Create owner account from private key
export function createOwnerAccount(privateKey: string): Account {
    return privateKeyToAccount(privateKey as `0x${string}`);
}

// Create public client for Sepolia
export function createPublicClientForSepolia(): PublicClient {
    return createPublicClient({
        chain: baseSepolia,
        transport: http()
    });
}

// Create Pimlico client instance
export function createPimlicoClientInstance(apiKey: string) {
    return createPimlicoClient({
        transport: http('https://api.pimlico.io/v1/sepolia/rpc'),
        apiKey
    });
}